package com.test1back.testconexionback;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class TestconexionbackApplicationTests {

	@Test
	void contextLoads() {
	}

}
