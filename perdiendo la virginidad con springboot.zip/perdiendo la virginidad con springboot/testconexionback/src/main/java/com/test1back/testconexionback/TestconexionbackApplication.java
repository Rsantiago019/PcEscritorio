package com.test1back.testconexionback;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class TestconexionbackApplication {

	public static void main(String[] args) {
		SpringApplication.run(TestconexionbackApplication.class, args);
	}

}
