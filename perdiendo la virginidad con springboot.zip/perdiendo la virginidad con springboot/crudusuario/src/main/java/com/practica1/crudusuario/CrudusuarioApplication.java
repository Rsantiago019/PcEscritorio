package com.practica1.crudusuario;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CrudusuarioApplication {

	public static void main(String[] args) {
		SpringApplication.run(CrudusuarioApplication.class, args);
	}

}
